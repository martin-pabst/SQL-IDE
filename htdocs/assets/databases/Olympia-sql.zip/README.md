# Datenquelle

https://www.kaggle.com/the-guardian/olympic-games?select=winter.csv

Originalquelle: IOC Research and Reference Service, veröffentlicht von The Guardian's Datablog 

teilweise ins Deutsche übersetzt

# Lizenz

CC-BY-SA 4.0 

# Stand
November 2019
